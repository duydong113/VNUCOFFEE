</div><!-- /.container -->
</main>
<footer>
  <div class="container">
    <div class="footer-content">
      <div class="footer-section">
        <h3>About Us</h3>
        <ul>
          <li><a href="index.php?page=about">About Us</a></li>
          <li><a href="index.php?page=products">Products</a></li>
        </ul>
      </div>

      <div class="footer-section">
        <h3>Terms</h3>
        <ul>
          <li><a href="index.php?page=terms">Terms of Use</a></li>
          <p>Our </p>
        </ul>
      </div>

      <div class="footer-section">
        <h3>Order: 1800 6936</h3>
        <div class="contact-info">
          <h3>Contact Us</h3>
          <p>1st Floor - 1 TRINH VAN BO STREET<br>
        </div>
      </div>
    </div>

    <div class="footer-bottom">
      <p>VN Coffee and Tea Trading Services Joint Stock Company</p>
      <p>Legal Representative: TRAN ANH DUONG </p>
      <p>Phone: 0912-345-678 | Email: hi@thecofeshop.vn</p>
      <p>© 2025-<?php echo date('Y'); ?> VN Coffee and Tea Trading Services Joint Stock Company. All rights reserved</p>
    </div>
  </div>
</footer>

<!-- Optional JavaScript -->
<script src="js/main.js"></script>
</body>

</html>